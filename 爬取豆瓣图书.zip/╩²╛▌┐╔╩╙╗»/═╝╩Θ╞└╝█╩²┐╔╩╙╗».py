# encoding='utf-8'
import pandas as pd
import matplotlib.pylab as plt
import matplotlib as mpl
import wordcloud
from imageio import imread

def analysis_data():
    # 显示的最大行数和列数，如果超额就显示省略号，这个指的是多少个dataFrame的列。
    # pd.set_option('display.max_rows', 30000)
    pd.set_option('display.max_columns', 20)
    pd.set_option('display.width',None)
    pd.set_option("display.unicode.ambiguous_as_wide", True)  # 输出列表标签与列对齐
    pd.set_option("display.unicode.east_asian_width", True)  # 输出列表标签与列对齐

    # 读取文件
    novel=pd.read_excel("../数据分析/小说预处理文件.xlsx")
    literature=pd.read_excel("../数据分析/文学预处理文件.xlsx")
    prose=pd.read_excel("../数据分析/散文预处理文件.xlsx")
    story=pd.read_excel("../数据分析/童话预处理文件.xlsx")
    essay=pd.read_excel("../数据分析/杂文预处理文件.xlsx")
    poetry=pd.read_excel("../数据分析/诗歌预处理文件.xlsx")
    infoessay=pd.read_excel("../数据分析/随笔预处理文件.xlsx")
    famous=pd.read_excel("../数据分析/名著预处理文件.xlsx")

    books = [novel, literature, prose, story, essay, poetry, infoessay, famous]
    sorts = ['小说', '文学', '散文', '童话', '杂文', '诗歌', '随笔', '名著']

    for i in range(len(books)):
        books[i].sort_values(by=['图书评价数', '图书评分'], axis=0, ascending=[False, False], inplace=True)

        # 解决中文乱码问题
        mpl.rcParams['font.sans-serif'] = ['SimHei']
        mpl.rcParams['axes.unicode_minus'] = False
        plt.rcParams['font.size'] = 18  # 设置字体大小，全局有效
        plt.figure(figsize=(15, 10), dpi=100)
        colors=['r','g','b','m','c','y','b','m','y','g']
        explore=[0.15,0,0,0,0,0,0,0,0,0]
        plt.title("{}评价数最高的10本图书".format(sorts[i]),color='r')
        plt.pie(books[i][0:10]['图书评价数'].tolist(),labels=books[i][0:10]['书名'].tolist(),colors=colors,explode=explore,
                startangle=15,autopct='%2.lf%%',shadow=True)
        plt.axis('equal')
        plt.savefig('./图书评价数可视化/{}评价数最高的10本图书.jpg'.format(sorts[i]))
        print("保存{}评价数最高的10本图书成功".format(sorts[i]))
        plt.clf()

        mask = imread("./数据词云/pkq.jpg")
        txt = " ".join(books[i]['书名'].value_counts()[0:50].index.tolist())
        w = wordcloud.WordCloud(font_path="msyh.ttc", mask=mask, width=1000, height=700, background_color="black")
        w.generate(txt)
        w.to_file("./数据词云/{}评价词云.png".format(sorts[i]))

if __name__ == '__main__':
    analysis_data()