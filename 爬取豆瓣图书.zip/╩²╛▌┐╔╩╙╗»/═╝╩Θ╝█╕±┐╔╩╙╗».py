# encoding='utf-8'
import pandas as pd
import matplotlib.pylab as plt
import matplotlib as mpl
import wordcloud
from imageio import imread

def analysis_data():
    # 显示的最大行数和列数，如果超额就显示省略号，这个指的是多少个dataFrame的列。
    # pd.set_option('display.max_rows', 30000)
    pd.set_option('display.max_columns', 20)
    pd.set_option('display.width',None)
    pd.set_option("display.unicode.ambiguous_as_wide", True)  # 输出列表标签与列对齐
    pd.set_option("display.unicode.east_asian_width", True)  # 输出列表标签与列对齐

    # 读取文件
    novel=pd.read_excel("../数据分析/小说预处理文件.xlsx")
    literature=pd.read_excel("../数据分析/文学预处理文件.xlsx")
    prose=pd.read_excel("../数据分析/散文预处理文件.xlsx")
    story=pd.read_excel("../数据分析/童话预处理文件.xlsx")
    essay=pd.read_excel("../数据分析/杂文预处理文件.xlsx")
    poetry=pd.read_excel("../数据分析/诗歌预处理文件.xlsx")
    infoessay=pd.read_excel("../数据分析/随笔预处理文件.xlsx")
    famous=pd.read_excel("../数据分析/名著预处理文件.xlsx")

    books = [novel, literature, prose, story, essay, poetry, infoessay, famous]
    sorts = ['小说', '文学', '散文', '童话', '杂文', '诗歌', '随笔', '名著']

    for i in range(len(books)):
        # print("所获取信息中{}图书价格区间".format(sorts[i]).center(100, "—"))
        c10 = len(books[i][books[i]['图书价格'] < 10])
        c20 = len(books[i][(books[i]['图书价格'] >= 10) & (books[i]['图书价格'] < 20)])
        c30 = len(books[i][(books[i]['图书价格'] >= 20) & (books[i]['图书价格'] < 30)])
        c40 = len(books[i][(books[i]['图书价格'] >= 30) & (books[i]['图书价格'] < 40)])
        c50 = len(books[i][(books[i]['图书价格'] >= 40) & (books[i]['图书价格'] < 50)])
        c60 = len(books[i][(books[i]['图书价格'] >= 50) & (books[i]['图书价格'] < 60)])
        c70 = len(books[i][(books[i]['图书价格'] >= 60) & (books[i]['图书价格'] < 70)])
        c80 = len(books[i][(books[i]['图书价格'] >= 70) & (books[i]['图书价格'] < 80)])
        c90 = len(books[i][(books[i]['图书价格'] >= 80) & (books[i]['图书价格'] < 90)])
        # print("0~9元：{}本\n10~19元：{}本\n20~29元：{}本\n"
        #       "30~39元：{}本\n40~49元：{}本\n50~59元：{}本\n"
        #       "60~69元：{}本\n70~79元：{}本\n80~89元：{}本".format(c10, c20, c30, c40, c50,c60,c70,c80,c90))

        # 解决中文乱码问题
        mpl.rcParams['font.sans-serif'] = ['SimHei']
        mpl.rcParams['axes.unicode_minus']=False
        plt.rcParams['font.size'] = 20  # 设置字体大小，全局有效
        # 创建窗口,分辨率:像素/英寸
        plt.figure(figsize=(30,10),dpi=100)
        x=["0~9","10~19","20~29","30~39","40~49","50~59","60~69","70~79","80~89"]
        y=[c10,c20,c30,c40,c50,c60,c70,c80,c90]
        # 绘制柱状图
        plt.bar(x,y,color='#87CEFA',alpha=1,label='本数')
        plt.title("{}图书价格区间".format(sorts[i]), fontproperties='SimHei', fontsize=30, color='red')
        # plt.tick_params(axis='x', labelsize=15)  # 设置x轴标签大小
        # plt.yticks(rotation=55)
        plt.xlabel('价格/元', fontproperties='SimHei', fontsize=30, color='b')
        plt.ylabel('数量', fontdict={'name': 'SimHei', 'size': '30', 'color': 'b'})
        plt.legend()#显示图例
        plt.subplots_adjust()
        # plt.show()#显示图形
        plt.savefig('./图书价格可视化/{}图书价格区间.jpg'.format(sorts[i]))
        print("保存{}图书价格区间成功".format(sorts[i]))

if __name__ == '__main__':
    analysis_data()