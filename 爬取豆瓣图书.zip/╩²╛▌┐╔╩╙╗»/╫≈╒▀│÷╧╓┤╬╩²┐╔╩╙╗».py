# encoding='utf-8'
import pandas as pd
import matplotlib as mpl
import matplotlib.pylab as plt
import wordcloud
from imageio import imread

def analysis_data():
    # 显示的最大行数和列数，如果超额就显示省略号，这个指的是多少个dataFrame的列。
    # pd.set_option('display.max_rows', 30000)
    pd.set_option('display.max_columns', 20)
    pd.set_option('display.width',None)
    pd.set_option("display.unicode.ambiguous_as_wide", True)  # 输出列表标签与列对齐
    pd.set_option("display.unicode.east_asian_width", True)  # 输出列表标签与列对齐

    # 读取文件
    novel=pd.read_excel("../数据分析/小说预处理文件.xlsx")
    literature=pd.read_excel("../数据分析/文学预处理文件.xlsx")
    prose=pd.read_excel("../数据分析/散文预处理文件.xlsx")
    story=pd.read_excel("../数据分析/童话预处理文件.xlsx")
    essay=pd.read_excel("../数据分析/杂文预处理文件.xlsx")
    poetry=pd.read_excel("../数据分析/诗歌预处理文件.xlsx")
    infoessay=pd.read_excel("../数据分析/随笔预处理文件.xlsx")
    famous=pd.read_excel("../数据分析/名著预处理文件.xlsx")

    books = [novel, literature, prose, story, essay, poetry, infoessay, famous]
    sorts = ['小说', '文学', '散文', '童话', '杂文', '诗歌', '随笔', '名著']
    for i in range(len(books)):
        print("创建{}作者排名前10的图片".format(sorts[i]))
        authors = books[i]['作者'].value_counts()[0:10]

        # 解决中文乱码问题
        mpl.rcParams['font.sans-serif'] = ['SimHei']
        mpl.rcParams['axes.unicode_minus']=False
        plt.rcParams['font.size'] = 20  # 设置字体大小，全局有效
        # 创建窗口,分辨率:像素/英寸
        plt.figure(figsize=(30,10),dpi=100)
        x=[authors.index[0],authors.index[1],authors.index[2],authors.index[3],authors.index[4],
           authors.index[5],authors.index[6],authors.index[7],authors.index[8],authors.index[9]]
        y=[authors[0],authors[1],authors[2],authors[3],authors[4],
           authors[5],authors[6],authors[7],authors[8],authors[9]]
        ynum=[authors[0],authors[1],authors[2],authors[3],authors[4],
           authors[5],authors[6],authors[7],authors[8],authors[9]]
        # 绘制柱状图
        plt.barh(x,y,color='#87CEFA',alpha=1,label='次数')
        plt.title('{}作者出现次数排名前10'.format(sorts[i]), fontproperties='SimHei', fontsize=30, color='red')
        # plt.tick_params(axis='x', labelsize=15)  # 设置x轴标签大小
        plt.yticks(rotation=55)
        plt.xlabel('出现次数', fontproperties='SimHei', fontsize=30, color='m')
        plt.ylabel('作者', fontdict={'name': 'SimHei', 'size': '30', 'color': 'm'})
        plt.legend()#显示图例
        plt.tight_layout()  # 调整整体空白
        plt.subplots_adjust(wspace=0, hspace=0)  # 调整子图间距
        # plt.show()#显示图形
        plt.savefig('./作者出现次数可视化/{}作者出现次数排名前10.jpg'.format(sorts[i]))
        print("保存{}作者排名前10的图片成功".format(sorts[i]))

        mask = imread("./数据词云/pkq.jpg")
        txt = " ".join(books[i]['作者'].value_counts()[0:50].index.tolist())
        w = wordcloud.WordCloud(font_path="msyh.ttc", mask=mask, width=1000, height=700, background_color="black")
        w.generate(txt)
        w.to_file("./数据词云/{}作者词云.png".format(sorts[i]))

if __name__ == '__main__':
    analysis_data()