# encoding='utf-8'
import pandas as pd
import matplotlib.pylab as plt
import matplotlib as mpl

def analysis_data():
    # 显示的最大行数和列数，如果超额就显示省略号，这个指的是多少个dataFrame的列。
    # pd.set_option('display.max_rows', 30000)
    pd.set_option('display.max_columns', 20)
    pd.set_option('display.width',None)
    pd.set_option("display.unicode.ambiguous_as_wide", True)  # 输出列表标签与列对齐
    pd.set_option("display.unicode.east_asian_width", True)  # 输出列表标签与列对齐

    # 读取文件
    novel=pd.read_excel("../数据分析/小说预处理文件.xlsx")
    literature=pd.read_excel("../数据分析/文学预处理文件.xlsx")
    prose=pd.read_excel("../数据分析/散文预处理文件.xlsx")
    story=pd.read_excel("../数据分析/童话预处理文件.xlsx")
    essay=pd.read_excel("../数据分析/杂文预处理文件.xlsx")
    poetry=pd.read_excel("../数据分析/诗歌预处理文件.xlsx")
    infoessay=pd.read_excel("../数据分析/随笔预处理文件.xlsx")
    famous=pd.read_excel("../数据分析/名著预处理文件.xlsx")

    books = [novel, literature, prose, story, essay, poetry, infoessay, famous]
    sorts = ['小说', '文学', '散文', '童话', '杂文', '诗歌', '随笔', '名著']

    for i in range(len(books)):
        print("所获取信息中{}图书评分区间".format(sorts[i]).center(100, "—"))
        c5 = len(books[i][books[i]['图书评分'] < 6])
        c6 = len(books[i][(books[i]['图书评分'] >= 6) & (books[i]['图书评分'] < 7)])
        c7 = len(books[i][(books[i]['图书评分'] >= 7) & (books[i]['图书评分'] < 8)])
        c8 = len(books[i][(books[i]['图书评分'] >= 8) & (books[i]['图书评分'] < 9)])
        c9 = len(books[i][(books[i]['图书评分'] >= 9) & (books[i]['图书评分'] < 10)])
        print("0~5.9分：{}本\n6~6.9分：{}本\n7.0~7.9分：{}本\n"
              "8.0~8.9分：{}本\n9.0~10.0分：{}本".format(c5,c6,c7,c8,c9))

        # 解决中文乱码问题
        mpl.rcParams['font.sans-serif'] = ['SimHei']
        mpl.rcParams['axes.unicode_minus']=False
        plt.rcParams['font.size'] = 20  # 设置字体大小，全局有效
        # 创建窗口,分辨率:像素/英寸
        plt.figure(figsize=(30,10),dpi=100)
        x=["0~5.9","6~6.9","7.0~7.9","8.0~8.9","9.0~10.0"]
        y=[c5,c6,c7,c8,c9]
        # 绘制柱状图
        plt.bar(x,y,color='#87CEFA',alpha=1,label='本数')
        plt.title("{}图书评分区间".format(sorts[i]), fontproperties='SimHei', fontsize=30, color='red')
        # plt.tick_params(axis='x', labelsize=15)  # 设置x轴标签大小
        # plt.yticks(rotation=55)
        plt.xlabel('分数', fontproperties='SimHei', fontsize=30, color='b')
        plt.ylabel('数量', fontdict={'name': 'SimHei', 'size': '30', 'color': 'b'})
        plt.legend()#显示图例
        plt.subplots_adjust()
        # plt.show()#显示图形
        plt.savefig('./图书评分区间可视化/{}图书评分区间.jpg'.format(sorts[i]))
        print("保存{}图书评分区间成功".format(sorts[i]))

if __name__ == '__main__':
    analysis_data()