# encoding='utf-8'
import pandas as pd
import matplotlib as mpl
import matplotlib.pylab as plt

def analysis_data():
    # 显示的最大行数和列数，如果超额就显示省略号，这个指的是多少个dataFrame的列。
    # pd.set_option('display.max_rows', 30000)
    pd.set_option('display.max_columns', 20)
    pd.set_option('display.width',None)
    pd.set_option("display.unicode.ambiguous_as_wide", True)  # 输出列表标签与列对齐
    pd.set_option("display.unicode.east_asian_width", True)  # 输出列表标签与列对齐

    # 读取文件
    novel=pd.read_excel("../数据分析/小说预处理文件.xlsx")
    literature=pd.read_excel("../数据分析/文学预处理文件.xlsx")
    prose=pd.read_excel("../数据分析/散文预处理文件.xlsx")
    story=pd.read_excel("../数据分析/童话预处理文件.xlsx")
    essay=pd.read_excel("../数据分析/杂文预处理文件.xlsx")
    poetry=pd.read_excel("../数据分析/诗歌预处理文件.xlsx")
    infoessay=pd.read_excel("../数据分析/随笔预处理文件.xlsx")
    famous=pd.read_excel("../数据分析/名著预处理文件.xlsx")

    books = [novel, literature, prose, story, essay, poetry, infoessay, famous]
    sorts = ['小说', '文学', '散文', '童话', '杂文', '诗歌', '随笔', '名著']

    booknamehigh=[]
    booknamelow=[]
    bookscorehigh=[]
    bookscorelow=[]
    for i in range(len(books)):
        max = books[i]['图书评分'].argmax()
        min = books[i]['图书评分'].argmin()
        booknamehigh.append(books[i].loc[max, '书名'])
        booknamelow.append(books[i].loc[min, '书名'])
        bookscorehigh.append(books[i].loc[max, '图书评分'])
        bookscorelow.append(books[i].loc[min, '图书评分'])

    # 解决中文乱码问题
    mpl.rcParams['font.sans-serif'] = ['SimHei']
    mpl.rcParams['axes.unicode_minus'] = False
    dates= ['小说', '文学', '散文', '童话', '杂文', '诗歌', '随笔', '名著']
    plt.figure(dpi=100, figsize=(6, 3))
    plt.plot(dates, bookscorehigh, label='最大值', c='b', alpha=0.5)
    plt.plot(dates, bookscorehigh, label='最小值', c='r', alpha=0.5)
    plt.fill_between(dates, bookscorehigh, bookscorelow, facecolor='orange', alpha=0.5)
    plt.title('所获信息中最高分和最低分', fontsize=10,color='r')
    plt.xlabel('类别', fontsize=7,color='m')
    plt.ylabel('分数', fontsize=7,color='m')
    plt.tick_params(axis='both', which='major', labelsize=7)
    plt.legend()
    plt.savefig('./图书评分可视化/所获信息中最高分和最低分.jpg')
    print('Done')

if __name__ == '__main__':
    analysis_data()