import csv
import random
import time
import requests
from bs4 import BeautifulSoup


def douban(sort,page):
    url='https://book.douban.com/tag/{}?start={}&type=T'.format(sort,page)
    # 请求的头部，User-Agent为浏览器的类型
    headers={'User-Agent':'Mozilla/5.0(Windows NT 6.1;WOW64) AppleWebKit/537.36(KHTML,like Gecko)Chrome/58.0.3029.96 Safari/537.36'}
    proxy_list = [
        '203.143.18.1:8080',
        '220.118.19.148:8000',
        '125.88.75.151:3128'
    ]
    proxy = random.choice(proxy_list)
    proxies = {
        'http': 'http://' + proxy
    }
    # requests获取html
    html = requests.get(url, headers=headers,proxies=proxies)
    # 写入文件
    with open('豆瓣图书.html', 'wb') as f:
        f.write(html.content)
    f.close()
    # 创建BeautifulSoup对象
    soup = BeautifulSoup(html.content, "html.parser")
    items = soup.find("ul", class_="subject-list").find_all('li')
    books=[]
    # 遍历所有列表项
    for item in items:
        book={} #临时存储
        # 书名
        try:
            book['书名'] = item.find('h2', class_='').get_text().replace(' ','').replace('\n','')
        except:
            book['书名'] = ""
        # 图书信息
        try:
            book['图书信息'] = item.find('div', class_='pub').get_text().replace(' ','').replace('\n','')
        except:
            book['图书信息'] = ''
        # # 图书星级
        # try:
        #     book['图书星级'] = item.find('span', class_='allstar45').get('class').replace(' ','')
        # except:
        #     book['图书星级'] = ""
        # 图书评分
        try:
            book['图书评分'] = item.find('span', class_='rating_nums').get_text().replace(' ','').replace('\n','')
        except:
            book['图书评分'] = ""
        # 图书评价数
        try:
            book['图书评价数'] = item.find('span', class_='pl').get_text().replace(' ','').replace('\n','')
        except:
            book['图书评价数'] = ""
        # 图书说明
        try:
            book['图书说明'] = item.find('p').get_text().replace(' ','').replace('\n','')
        except:
            book['图书说明'] = ""
        # 图书价格
        try:
            book['图书价格'] = item.find('span',class_='buy-info').get_text().replace(' ','').replace('\n','')
        except:
            book['图书价格'] = ""
        books.append(book)
    # print(book)
    return books

def save_douban():
    sorts=['小说','文学','散文','诗歌','童话','名著','杂文','随笔']
    page=0
    for sort in sorts:
        # 新建一个csv文件
        book = open('豆瓣{}.csv'.format(sort), 'w', encoding='utf-8', newline='')
        writer = csv.writer(book)  # CSV写入的参数为一个list
        writer.writerow(['书名', '图书信息', '图书评分', '图书评价数', '图书说明', '图书价格'])
        while page<=1000: #每个模块1000条数据
            time.sleep(random.random()*10)  # 设置单个的爬取时间间隔，避免IP被封
            items=douban(sort,page)
            # 将信息写入CSV文件中
            for item in items:
                writer.writerow(
                    [item['书名'], item['图书信息'], item['图书评分'], item['图书评价数'], item['图书说明'], item['图书价格']])
            print("爬取{}第{}页完毕".format(sort,page))
            page+=20 #每页20条数据
        page=0
        # 关闭csv文件
        book.close()

if __name__ == '__main__':
    save_douban()