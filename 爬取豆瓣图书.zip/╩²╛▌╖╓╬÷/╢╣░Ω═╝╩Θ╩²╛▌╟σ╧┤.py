import pandas as pd


def clean_data():
    # 显示的最大行数和列数，如果超额就显示省略号，这个指的是多少个dataFrame的列。
    # pd.set_option('display.max_rows', 30000)
    pd.set_option('display.max_columns', 20)
    pd.set_option('display.width', None)
    pd.set_option("display.unicode.ambiguous_as_wide", True)  # 输出列表标签与列对齐
    pd.set_option("display.unicode.east_asian_width", True)  # 输出列表标签与列对齐

    # 读取爬虫文件夹下的csv文件
    novel = pd.read_csv(open("../爬虫/豆瓣小说.csv", encoding="utf-8"), sep=',', header=0)
    literature = pd.read_csv(open("../爬虫/豆瓣文学.csv", encoding="utf-8"), sep=',', header=0)
    prose = pd.read_csv(open("../爬虫/豆瓣散文.csv", encoding="utf-8"), sep=',', header=0)
    story = pd.read_csv(open("../爬虫/豆瓣童话.csv", encoding="utf-8"), sep=',', header=0)
    essay = pd.read_csv(open("../爬虫/豆瓣杂文.csv", encoding="utf-8"), sep=',', header=0)
    poetry = pd.read_csv(open("../爬虫/豆瓣诗歌.csv", encoding="utf-8"), sep=',', header=0)
    infoessay = pd.read_csv(open("../爬虫/豆瓣随笔.csv", encoding="utf-8"), sep=',', header=0)
    famous = pd.read_csv(open("../爬虫/豆瓣名著.csv", encoding="utf-8"), sep=',', header=0)

    books = [novel, literature, prose, story, essay, poetry, infoessay, famous]
    sorts = ['小说', '文学', '散文', '童话', '杂文', '诗歌', '随笔', '名著']
    # 数据清洗前有的数据
    for i in range(len(books)):
        print('数据清洗关于{}有{}条数据'.format(sorts[i], books[i].size))

    # 小说、文学、散文、童话、诗歌、随笔、名著、杂文
    for i in range(len(books)):
        books[i].dropna(axis=0, how='all', inplace=True)  # 删除全是NaN的行和列
        books[i].dropna(axis=1, how='all', inplace=True)
        books[i].drop_duplicates(inplace=True)  # 删除重复行
        bookinfo = books[i]['图书信息'].str.split("/", expand=True)  # 按字符/分割列
        books[i]['作者'] = bookinfo[0]
        bookcomment = books[i]['图书评价数'].str.replace('人评价', '')
        bookcomment = bookcomment.str.replace('(', '', regex=True)
        bookcomment = bookcomment.str.replace(')', '', regex=True)
        bookcomment = bookcomment.str.replace('少于', '').replace('目前无', '0')
        books[i]['图书评价数'] = bookcomment.astype(float)
        bookprice = books[i]['图书价格'].str.replace('纸质版', '')
        bookprice = bookprice.str.replace('元', '')
        bookprice = bookprice.str.replace('起', '')
        books[i]['图书价格'] = bookprice.astype(float)
        books[i].drop(['图书信息', '图书说明'], axis=1, inplace=True)  # 删除“图书信息”和“图书说明”列
        books[i] = books[i].fillna('')  # 数据替换
        books[i] = books[i][["书名", "作者", "图书评分", "图书评价数", "图书价格"]]  # 列名重排
        books[i].index = books[i]['书名']  # 将"书名"作为索引
        del books[i]['书名']
        books[i].to_excel("{}预处理文件.xlsx".format(sorts[i]))  # 将数据存入xlsx文件中
    print("清洗后成功存入预处理文件!")

    for i in range(len(books)):
        print('数据清洗后关于{}有{}条数据'.format(sorts[i], books[i].size))


if __name__ == '__main__':
    clean_data()
