# encoding='utf-8'
import pandas as pd

def analysis_data():
    # 显示的最大行数和列数，如果超额就显示省略号，这个指的是多少个dataFrame的列。
    # pd.set_option('display.max_rows', 30000)
    pd.set_option('display.max_columns', 20)
    pd.set_option('display.width',None)
    pd.set_option("display.unicode.ambiguous_as_wide", True)  # 输出列表标签与列对齐
    pd.set_option("display.unicode.east_asian_width", True)  # 输出列表标签与列对齐

    # 读取文件
    novel=pd.read_excel("小说预处理文件.xlsx")
    literature=pd.read_excel("文学预处理文件.xlsx")
    prose=pd.read_excel("散文预处理文件.xlsx")
    story=pd.read_excel("童话预处理文件.xlsx")
    essay=pd.read_excel("杂文预处理文件.xlsx")
    poetry=pd.read_excel("诗歌预处理文件.xlsx")
    infoessay=pd.read_excel("随笔预处理文件.xlsx")
    famous=pd.read_excel("名著预处理文件.xlsx")

    books = [novel, literature, prose, story, essay, poetry, infoessay, famous]
    sorts = ['小说', '文学', '散文', '童话', '杂文', '诗歌', '随笔', '名著']

    # print("所获取信息中原数据".center(100, "—"), '\n', books[i],'\n')
    # print("所获取信息中每个作者数据条目数".center(100, "—"), '\n', books[i]['作者'].value_counts(),'\n')
    for i in range(len(books)):
        print("所获取信息中{}作者出现最多次的是".format(sorts[i]).center(100, "—"))
        author=books[i]['作者'].value_counts()[0:1]
        print(author)

        print("所获取信息中{}评分最高和最低的图书".format(sorts[i]).center(100, "—"))
        max=books[i]['图书评分'].argmax()
        min=books[i]['图书评分'].argmin()
        print('图书评分最高的书名和作者：\n',books[i].loc[max,'书名'],'\n',books[i].loc[max, '作者'],'\n')
        print('图书评分最低的书名和作者：\n',books[i].loc[min,'书名'],'\n',books[i].loc[min, '作者'])

        print("所获取信息中{}评价数最高的图书是".format(sorts[i]).center(100, "—"))
        books[i].sort_values(by=['图书评价数', '图书评分'], axis=0, ascending=[False, False], inplace=True)
        print(books[i].loc[0,'书名'])

        print("所获取信息中{}售价最高和最低的图书是".format(sorts[i]).center(100, "—"))
        max = books[i]['图书价格'].argmax()
        min = books[i]['图书价格'].argmin()
        print('图书价格最高的书名和作者：\n', books[i].loc[max, '书名'], '\n', books[i].loc[max, '作者'], '\n')
        print('图书价格最低的书名和作者：\n', books[i].loc[min, '书名'], '\n', books[i].loc[min, '作者'])

        print("所获取信息中{}作者排名前10的是".format(sorts[i]).center(100, "—"))
        author = books[i]['作者'].value_counts()[0:10]
        print(author)

        print("所获取信息中{}评分最高的10本图书是".format(sorts[i]).center(100, "—"))
        books[i].sort_values(by=['图书评分','图书评价数'], axis=0, ascending=[False, False], inplace=True)
        print(books[i][0:10]['书名'])

        print("所获取信息中{}评价数最高的10本图书是".format(sorts[i]).center(100, "—"))
        books[i].sort_values(by=['图书评价数', '图书评分'], axis=0, ascending=[False, False], inplace=True)
        print(books[i][0:10]['书名'])

        print("所获取信息中{}价格最高的10本图书是".format(sorts[i]).center(100, "—"))
        books[i].sort_values(by=['图书价格', '图书评分'], axis=0, ascending=[False, False], inplace=True)
        print(books[i][0:10]['书名'])

        print("所获取信息中{}平均评分是".format(sorts[i]).center(100, "—"))
        scoremean=round(books[i]['图书评分'].mean(axis=0),2)
        print(scoremean)

        print("所获取信息中{}图书评分区间".format(sorts[i]).center(100, "—"))
        c5 = len(books[i][books[i]['图书评分'] < 6])
        c6 = len(books[i][(books[i]['图书评分'] >= 6) & (books[i]['图书评分'] < 7)])
        c7 = len(books[i][(books[i]['图书评分'] >= 7) & (books[i]['图书评分'] < 8)])
        c8 = len(books[i][(books[i]['图书评分'] >= 8) & (books[i]['图书评分'] < 9)])
        c9 = len(books[i][(books[i]['图书评分'] >= 9) & (books[i]['图书评分'] < 10)])
        print("0~5.9分：{}本\n6~6.9分：{}本\n7.0~7.9分：{}本\n"
              "8.0~8.9分：{}本\n9.0~10.0分：{}本".format(c5,c6,c7,c8,c9))

        print("所获取信息中{}图书价格区间".format(sorts[i]).center(100, "—"))
        c10 = len(books[i][books[i]['图书价格'] < 10])
        c20 = len(books[i][(books[i]['图书价格'] >= 10) & (books[i]['图书价格'] < 20)])
        c30 = len(books[i][(books[i]['图书价格'] >= 20) & (books[i]['图书价格'] < 30)])
        c40 = len(books[i][(books[i]['图书价格'] >= 30) & (books[i]['图书价格'] < 40)])
        c50 = len(books[i][(books[i]['图书价格'] >= 40) & (books[i]['图书价格'] < 50)])
        c60 = len(books[i][(books[i]['图书价格'] >= 50) & (books[i]['图书价格'] < 60)])
        c70 = len(books[i][(books[i]['图书价格'] >= 60) & (books[i]['图书价格'] < 70)])
        c80 = len(books[i][(books[i]['图书价格'] >= 70) & (books[i]['图书价格'] < 80)])
        c90 = len(books[i][(books[i]['图书价格'] >= 80) & (books[i]['图书价格'] < 90)])
        print("0~9元：{}本\n10~19元：{}本\n20~29元：{}本\n"
              "30~39元：{}本\n40~49元：{}本\n50~59元：{}本\n"
              "60~69元：{}本\n70~79元：{}本\n80~89元：{}本".format(c10, c20, c30, c40, c50,c60,c70,c80,c90))

if __name__ == '__main__':
    analysis_data()